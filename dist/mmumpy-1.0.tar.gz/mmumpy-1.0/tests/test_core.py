import bumpy as bp

def test_transpose():
    assert bp.transpose([[1,2,3],[4,5,6]]) == [['1','4'],['2','5'],['3','6']]
