from setuptools import setup, find_packages

setup(
    name="bumpy",
    version="1.0",
    packages=find_packages(),
    install_requires=[],
    autor="rkb121541",
    description="Matrix library",
)
