from .core import (
    shape,
    transpose,
    inverse,
)
