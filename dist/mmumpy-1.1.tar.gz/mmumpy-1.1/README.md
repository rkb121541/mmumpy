# mmumpy

You can pip install it by doing:

```sh
pip install mmumpy
```

This package includes my implementations of some of numpy's matrix manipulations.
